
document.getElementById("moduloContatto").addEventListener("submit", function(event) {
    event.preventDefault();
    document.getElementById("conferma").style.display = "block";
});
